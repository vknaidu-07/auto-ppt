import React from "react";

export default function PreviewArea() {
  return (
    <section className="rb-preview">
      <div className="rb-preview-inner">
        <div className="rb-icon">📄</div>
        <h2 className="rb-preview-title">Preview Area</h2>
        <p className="rb-preview-sub">Your generated presentation will appear here. Enter a topic and click generate to get started.</p>
        <div className="rb-sample-card">
          <div className="card-title">Sample Slide</div>
          <div className="card-body">Title — Key point one — Supporting bullet two</div>
        </div>
      </div>
    </section>
  );
}
