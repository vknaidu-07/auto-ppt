import React from "react";

export default function Header() {
  return (
    <header className="rb-header">
      <div className="rb-brand">
        <div className="rb-logo">JIVA</div>
        <div className="rb-title">Auto PPT<span className="rb-dot">.</span></div>
      </div>
      <nav className="rb-nav">
        <a href="#" className="rb-cta">Generate</a>
      </nav>
    </header>
  );
}
