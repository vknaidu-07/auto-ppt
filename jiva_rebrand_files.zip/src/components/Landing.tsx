import React from "react";

export default function Landing() {
  return (
    <section className="rb-landing">
      <h1 className="rb-h1">Auto PPT — AI Presentation Generator</h1>
      <p className="rb-lead">Turn any topic into a polished, corporate-grade PowerPoint in seconds. Branded for JIVA.</p>

      <div className="rb-controls">
        <label className="field">
          <span>Topic</span>
          <input id="topic" placeholder="E.g. Market entry strategy for India" />
        </label>

        <div className="row">
          <label className="field small">
            <span>Slides</span>
            <input id="slides" type="number" min="1" max="50" defaultValue={8} />
          </label>

          <label className="field small">
            <span>Style</span>
            <select id="style">
              <option>Corporate</option>
              <option>Minimal</option>
              <option>Modern</option>
            </select>
          </label>
        </div>

        <button className="rb-primary" id="generate">Generate Presentation</button>

        <p className="rb-note">Pro tip: Use short, descriptive topics for best results.</p>
      </div>
    </section>
  );
}
