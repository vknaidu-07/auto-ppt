import React from "react";
import Header from "./components/Header";
import Landing from "./components/Landing";
import PreviewArea from "./components/PreviewArea";
import "./styles/rebrand.css";

export default function App() {
  return (
    <div className="rebrand-app">
      <Header />
      <main className="container">
        <div className="left">
          <Landing />
        </div>
        <div className="right">
          <PreviewArea />
        </div>
      </main>
    </div>
  );
}
